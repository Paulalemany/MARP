/*@ <authors>
 *
 * MARP86 Nombre Apellidos
 * MARP99 Nombre Apellidos
 *
 *@ </authors> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <queue>
using namespace std;


/*@ <answer>
 
 Sustituye este párrafo por un comentario general sobre la solución, 
 explicando cómo se resuelve el problema y cuál es el coste de la solución, 
 en función del tamaño del problema.
 
 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>



bool resuelveCaso() {
  
  // leemos la entrada
  int D, C, N;
  cin >> D >> C >> N;
  if (!cin) return false;
  
  // leer el resto del caso y resolverlo
  
  
  
  
  return true;
}

//@ </answer>
//  Lo que se escriba debajo de esta línea ya no forma parte de la solución.

int main() {
   // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
   ifstream in("casos.txt");
   if (!in.is_open())
      cout << "Error: no se ha podido abrir el archivo de entrada." << endl;
   auto cinbuf = cin.rdbuf(in.rdbuf());
#endif

  // Resolvemos
  while (resuelveCaso());
  
  // para dejar todo como estaba al principio
#ifndef DOMJUDGE
  cin.rdbuf(cinbuf);
#endif
  return 0;
}
